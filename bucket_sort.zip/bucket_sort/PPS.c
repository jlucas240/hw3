/* PPS: Parallel performance summarizer 
** Tyler Simon 
** 01/30/2014

To compile:
cc -o PPS PPS.c


to run: 
./PPS data/data.txt | column -t

data format:
[cores] [runtime(sec)]
1 39.3
2 20.5
4 11.25
6 7.2
8 5.15
12 3.67
16 2.9
32 1.7
64 1.6

*/

#include <stdlib.h>
#include <stdio.h>
#include <math.h>
#include <string.h>

/*Power is the cube of frequency*/
//#define power(x,y) (y*((x)*(x)*(x)))

double get_parfrac(int, double);
double amd(double, int);
float karp_flatt(int, float);

int main(int argc, char **argv)
{
int cores;
float T_n,memory_t, compute_t;
FILE *fp;
char inputfile[255];
char line[80];

double speedup_Amdahl=0.0;
double dynamic_speedup=0.0;
double speedup=0;
double par_frac;

if (argc > 1)strcpy(inputfile,argv[1]);
else {
	printf("Usage:%s <inputfile>\n", argv[0]);
	exit(0);
	}


int first=1;
float compute_t_serial;
float eff;
float t_overhead;
float K;
float gustafson;
float amdahl_max_s;
float k_flatt;


//printf(" %s: Results for %s\n", timestring(), proctype);

printf("\n\n#Cores\t#Runtime\t#Speedup\t#Par_frac\t#Eff.\t#Amdahl(S)\t#Gust(SS)\t#Karp_Flatt\n");
printf("#----\t#-------\t#-----\t#----\t#------\t#------\t#---\t#---------\n");

if( (fp=fopen(inputfile, "r")) != NULL)
	{
	while(fgets(line, 80, fp) != NULL)
		{
	 	/* get a line, up to 80 chars from fr.  done if NULL */
		if(first) 
			{
			sscanf(line,"%d %f", &cores,&compute_t_serial);
			first=0;
		/* Make calculations for the serial (1 processor) case	*/
		speedup=1.00; //for the single processor case
		par_frac=get_parfrac(cores,speedup);
		speedup_Amdahl=amd(par_frac,cores);
		eff = (float)speedup/cores;
		t_overhead=0;
		gustafson=1;
		k_flatt=0;

		printf("%d\t%.2f\t%.3f\t%.3f\t%.3f\t%.3f\t%.3f\t%.3f\n", cores,compute_t_serial, speedup, par_frac, eff, speedup_Amdahl, gustafson, k_flatt);
			}
		else {
			sscanf(line,"%d %f", &cores,&compute_t);

			speedup=compute_t_serial*(1/compute_t);
	
			par_frac=get_parfrac(cores,speedup);

		/* Run Amdahl*/
		speedup_Amdahl=amd(par_frac,cores);

		/* get efficiency */
		eff = speedup/cores;
		

		/* Max Amdahl value */
		amdahl_max_s=1/(1-par_frac);

		/* serial fraction*/
		k_flatt=karp_flatt(cores,speedup);

		/* gustafson's law*/
		//gustafson=(1-par_frac)+(par_frac*cores);
		gustafson=cores-k_flatt*(cores - 1);
	     
		/* Print Results*/
		printf("%d\t%.2f\t%.3f\t%.3f\t%.3f\t%.3f\t%.3f\t%.2f\n", cores,compute_t, speedup, par_frac, eff, speedup_Amdahl, gustafson, k_flatt);

			}
		}//reading file
	}
else 
	{
	perror("couldn't open file");
	exit(1);
	}
fclose(fp);

return 0;
}//end main loop


/*pg 168 Quinn*/
float karp_flatt(int cores,float speedup)
	{
	return (double)((1/speedup)-(1/(float)cores))/(1-(1/(float)cores));
	}

/*Amdahl's law*/
double amd(double par, int n)
        {
        double speedup;
        speedup=1/((1-par)+(par/n));
        return speedup;
        }


/* derives parallel fraction from Amdahl*/
double get_parfrac(int n,double speedup_in)
{
double i;
float epsilon=0.001;
double speedup=0.0;
double pfrac=0.0;

for (i=1.0; i>=0.00; i-=epsilon)
	{
	speedup=amd(i,n);
	if (speedup_in>= n){pfrac=1.0;break;}

	if(speedup_in <= (speedup+epsilon) && speedup >= (speedup-epsilon))
		{
		pfrac=i;
		}
	}
return (pfrac);
}




