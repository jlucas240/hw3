import random

i = 0
f = open("testMe.txt", "w")

while i < 100000:
    val = random.randint(0, 500000)
    f.write(str(val)+"\n")
    i = i+1
f.close()