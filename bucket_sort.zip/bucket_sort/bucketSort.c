#include <pthread.h>
#include <stdio.h>
#include <stdbool.h> 
#include <stdlib.h>
#include <mpi.h>
#include "timer.h"

/*
    NOTE: number of processors must be a power of 2
*/

bool readIn(char* FileName);
bool bucketSort(int p_id, int rank);
bool TheEndGame(int p, int rank);

int* data;
int size; bool go = false;

int main(void){
    double start, finish, elapsed;

    int p, myRank;

    // start MPI
    MPI_Init(NULL,NULL);
    MPI_Comm_size(MPI_COMM_WORLD, &p);
    MPI_Comm_rank(MPI_COMM_WORLD, &myRank);
    

    if(myRank == 0){
        GET_TIME(start);
        if (readIn("testMe.txt")== 0){
            printf("error with file try anouther") ;
            exit(1);
            }
        

        MPI_Bcast(&size, 1, MPI_INT, 0, MPI_COMM_WORLD);
        MPI_Bcast(data, size, MPI_INT, 0, MPI_COMM_WORLD);
        go = true;
        MPI_Bcast(&go, 1, MPI_C_BOOL, 0, MPI_COMM_WORLD);
    }
    else{
        while(go == false){
            // punishmet for bad treads that thought they were fast.
            MPI_Bcast(&size, 1, MPI_INT, 0, MPI_COMM_WORLD);
            data = (int*)calloc(size, sizeof(int));
            MPI_Bcast(data, size, MPI_INT, 0, MPI_COMM_WORLD);
            MPI_Bcast(&go, 1, MPI_C_BOOL, 0, MPI_COMM_WORLD);
        }
    }

    bucketSort(p, myRank);

    if(myRank == 0){
        FILE* outFile = fopen("results.txt", "w");
        for(int i = 0; i < size; i++){
            fprintf(outFile, "%d\n", data[i]);
        }
        GET_TIME(finish);
        elapsed = finish - start;
        printf("The code to be timed took %e seconds\n", elapsed);
        free(outFile);
    }
    free(data);
    

    MPI_Finalize();
    exit(0);
}

bool bucketSort(int p, int rank){

    int numElements = size/p;
    int start;
    int end;
    if(rank == 0){
        start =  0;
        end = numElements;
    }
    else if(rank == p-1){
        start = rank *numElements;
        end = size;
    }
    else{
        start = rank *numElements;
        end = (rank+ 1) *numElements;
    }

    //Do insertion sort here!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
    //int i = start+1;
    int hold;
    for(int i = start+1; i < end; ++i){
        int k = i;
        for (int j = i-1; j >= start; --j){  
            if(data[k] < data[j]){
                hold = data[k];
                data[k] = data[j];
                data[j] = hold;
                if( k > start)
                    --k;
                else
                j = start -1;
                
            }
            else 
                j = start -1;
        }
    }
    
    // merge 2 buckets here
    int numP = p;

    for( int i = 2; numP > 1; i*= 2){
        if(numP%2 == 0){
            if(rank%i == 0 ){
                // receve data
                int* data2 = (int*)calloc(size, sizeof(int));
                int start2, end2;
                MPI_Status status;
                MPI_Recv(data2, size, MPI_INT, rank+(rank+i/2)%i, 0, MPI_COMM_WORLD, &status);
                MPI_Recv(&start2, 1, MPI_INT, rank+(rank+i/2)%i, 0, MPI_COMM_WORLD, &status);
                MPI_Recv(&end2, 1, MPI_INT, rank+(rank+i/2)%i, 0, MPI_COMM_WORLD, &status); 
                // merge the two buckets!!!!!!!!!!!!!!!!

                for(int j = start2; j < end2; ++j)
                    data[j]=data2[j];

                for (int j = end; j < end2; ++j){
                    int l = j;
                    for (int k = j-1; k >= start; --k){
                        if(data[l] < data[k]){
                            hold = data[l];
                            data[l] = data[k];
                            data[k] = hold;
                            if( k > start)
                                --l;
                            else
                                j = start -1;
                        }
                        else 
                            k = start -1;
                        
                    }
                }
                end = end2;

            }
            else if(rank%i == i/2){
                // send data
                MPI_Send(data, size, MPI_INT, rank -(rank%i), 0, MPI_COMM_WORLD);
                MPI_Send(&start, 1, MPI_INT, rank -(rank%i), 0, MPI_COMM_WORLD);
                MPI_Send(&end, 1, MPI_INT, rank -(rank)%i, 0, MPI_COMM_WORLD);
            }
            numP = numP/2 ;
        }
        else{
            if(rank%i == 0 && rank != 0){
                // receve data
                int* data2 = (int*)calloc(size, sizeof(int));
                int start2, end2;
                MPI_Status status;
                MPI_Recv(data2, size, MPI_INT, rank-(rank+i/2)%i, 0, MPI_COMM_WORLD, &status);
                MPI_Recv(&start2, 1, MPI_INT, rank-(rank+i/2)%i, 0, MPI_COMM_WORLD, &status);
                MPI_Recv(&end2, 1, MPI_INT, rank-(rank+i/2)%i, 0, MPI_COMM_WORLD, &status); 
                // merge the two buckets!!!!!!!!!!!!!!!!

                for(int j = start2; j < end2; ++j)
                    data[j]=data2[j];

                for (int j = start2; j < start; ++j){
                    int l = j;
                    for (int k = j-1; k >= start2; --k){
                        if(data[l] < data[k]){
                            hold = data[l];
                            data[l] = data[k];
                            data[k] = hold;
                            if( k > start2)
                                --l;
                            else
                                j = start2 -1;
                        }
                        else 
                            k = start2 -1;
                        
                    }
                }
                start = start2;

            }
            else if(rank%i == i/2){
                // send data
                MPI_Send(data, size, MPI_INT, rank +(rank%i), 0, MPI_COMM_WORLD);
                MPI_Send(&start, 1, MPI_INT, rank +(rank%i), 0, MPI_COMM_WORLD);
                MPI_Send(&end, 1, MPI_INT, rank +(rank)%i, 0, MPI_COMM_WORLD);
            }
            numP = numP/2 +1;

        }
    }
    

    return true;
}

bool readIn(char* FileName){
    char* value =  malloc(sizeof(int));
    int lines = 0;
    
    FILE* inFile = fopen(FileName, "r");
    
    if (! inFile)
        return false; 

    while(fgets(value, 50, inFile)){
        lines++;
    }
    fclose(inFile);
    size = lines;
    data = (int*)calloc(lines, sizeof(int));
    inFile = fopen(FileName, "r");

    int i = 0;
    int j = 0;
    fscanf(inFile, "%d", &i);
    while(!feof (inFile)){
        data[j] = i;
        ++j;
        fscanf(inFile, "%d", &i);
    }
    fclose(inFile);
    free(inFile);
    free(value);


    return true;
}