				NOTE:
This program run with a number of cores that is not a power of 2 the speed will be slower.
This is due to my implementation of merging the buckets.
this program uses open mpi to preform a bucket sort, in wich each bucket is sorted using 
insertion sort.

				USE:
compile: mpicc bucketSort.c -o bucket
run: mpiexec -np "number of processors" ./bucket

The randomNumberFileThing.py script can be ran to produce difren numbers in testMe.txt.

				OUTPUT:
The sorted file is in result.txt

				Results:
The sorting algorithm is a little slower when using a number of processors that is not a
power of 2 because of the comunication method used. This is beacuse there idle time for 
some treads as they wait for a bucket to murge with. Also, there is no significant 
improvment in speed up after 8 treads because of cpu limitaions. 
